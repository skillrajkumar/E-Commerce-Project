package com.ecommerce.project.exceptions;

public class AuthenticationFailException extends IllegalArgumentException{

	public AuthenticationFailException(String msg) {
		super(msg);
	}
}
